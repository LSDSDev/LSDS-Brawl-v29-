class Shop:
    """
    << Shop Offers IDs List >>

    0 = Free Brawl Box
    1 = Gold
    2 = Random Brawler
    3 = Brawler
    4 = Skin
    5 = StarPower/ Gadget
    6 = Brawl Box
    7 = Tickets
    8 = Power Points (for a specific brawler)
    9 = Token Doubler
    10 = Mega Box
    11 = Keys (???)
    12 = Power Points
    13 = EventSlot (???)
    14 = Big Box
    15 = AdBox (v12)
    16 = Gems
    19 = пин бравлера
    21 = пин пак
    22-23 = v30
    24 = скин вне раздела скинов
    25 = v33-34?

    """



    offers = [
    
         {
            'ID': 10,
            'OfferTitle': 'бокс',
            'Cost': 80,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 1,
            'BrawlerID': 0,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_chromatic',
            'Land': False
        },

        {
            'ID': 1,
            'OfferTitle': 'Special Offer',
            'Cost': 0,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 500,
            'BrawlerID': 0,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_generic',
            'Land': False
        },
        
        {
            'ID': 16,
            'OfferTitle': 'Special Offer',
            'Cost': 0,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 120,
            'BrawlerID': 0,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_coins',
            'Land': False
        },
        
        {
            'ID': 24,
            'OfferTitle': 'Special Offer',
            'Cost': 100,
            'OldCost': 200,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 1,
            'BrawlerID': 0,
            'SkinID': 52,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_generic',
            'Land': False
        },
        
        {
            'ID': 3,
            'OfferTitle': 'Special Offer',
            'Cost': 0,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 1,
            'BrawlerID': 39,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_lny',
            'Land': False
        },
        
        {
            'ID': 9,
            'OfferTitle': 'Special Offer',
            'Cost': 0,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 200,
            'BrawlerID': 0,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_special',
            'Land': False
        },
        
        {
            'ID': 21,
            'OfferTitle': 'Special Offer',
            'Cost': 0,
            'OldCost': 0,
            'Etype': 1,
            'ExT': 0,
            'Count': 1,
            'Multiplier': 200,
            'BrawlerID': 0,
            'SkinID': 0,
            'ShopType': 0,
            'ShopDisplay': 0,
            'Timer': 69420,
            'OfferBG': 'offer_special',
            'Land': False
        },


    ]


    gold = [
        {
            'Cost': 20,
            'Amount': 150
        },

        {
            'Cost': 50,
            'Amount': 400
        },

        {
            'Cost': 140,
            'Amount': 1200
        },

        {
            'Cost': 280,
            'Amount': 2600
        },

    ]

    boxes = [
        {
            'Name': 'Big Box',
            'Cost': 30,
            'Multiplier': 3
        },

        {
            'Name': 'Mega Box',
            'Cost': 80,
            'Multiplier': 10
        }

    ]


    token_doubler = {

        'Cost': 50,
        'Amount': 1000
    }


    def EncodeShopOffers(self):
        count = len(Shop.offers)
        self.writeVint(count)
        for i in range(count):
            x = Shop.offers[i]

            self.writeVint(x['Count'])

            self.writeVint(x['ID']) # xID
            self.writeVint(x['Multiplier']) # Ammount
            self.writeScId(16, x['BrawlerID'])
            self.writeVint(x['SkinID'])
            self.writeVint(x['ShopType'])  # [0 = Offer, 2 = Skins 3 = Star Shop]

            self.writeVint(x['Cost'])  # Cost
            self.writeVint(x['Timer']) # Timer

            self.writeVint(0)
            self.writeVint(100)
            self.writeBoolean(False)  # is Offer Purchased

            self.writeBoolean(False)
            self.writeVint(x['ShopDisplay'])  # [0 = Normal, 1 = Daily Deals]
            self.writeVint(x['OldCost'])
            self.writeVint(0)
            
            self.writeInt(0)
            self.write_string_reference(x['OfferTitle'])
            self.writeBoolean(False)
            self.writeString(x['OfferBG'])
            self.writeVint(0)
            self.writeBoolean(False)
            self.writeVint(x['Etype'])
            self.writeVint(x['ExT']) # % ExTra TExT